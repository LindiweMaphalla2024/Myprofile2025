# CSS_2025
A python code used for pulling data from a pythochemical website \
This should be run with anaconda and the following is required before executing the script: \
conda create -n webd -c bioconda -y \
conda activate webd \
conda install pip spyder -y \
pip install requests pubchempy pandas
